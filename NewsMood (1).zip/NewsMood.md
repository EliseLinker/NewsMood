
## Unit 7 | Assignment - Distinguishing Sentiments

## Background


__Twitter__ has become a wildly sprawling jungle of information&mdash;140 characters at a time. Somewhere between 350 million and 500 million tweets are estimated to be sent out _per day_. With such an explosion of data, on Twitter and elsewhere, it becomes more important than ever to tame it in some way, to concisely capture the essence of the data.

Choose __one__ of the following two assignments, in which you will do just that. Good luck!

## News Mood

In this assignment, you'll create a Python script to perform a sentiment analysis of the Twitter activity of various news oulets, and to present your findings visually.

Your final output should provide a visualized summary of the sentiments expressed in Tweets sent out by the following news organizations: __BBC, CBS, CNN, Fox, and New York times__.

![output_10_0.png](output_10_0.png)

![output_13_1.png](output_13_1.png)

The first plot will be and/or feature the following:

* Be a scatter plot of sentiments of the last __100__ tweets sent out by each news organization, ranging from -1.0 to 1.0, where a score of 0 expresses a neutral sentiment, -1 the most negative sentiment possible, and +1 the most positive sentiment possible.
* Each plot point will reflect the _compound_ sentiment of a tweet.
* Sort each plot point by its relative timestamp.

The second plot will be a bar plot visualizing the _overall_ sentiments of the last 100 tweets from each organization. For this plot, you will again aggregate the compound sentiments analyzed by VADER.

The tools of the trade you will need for your task as a data analyst include the following: tweepy, pandas, matplotlib, seaborn, textblob, and VADER.

Your final Jupyter notebook must:

* Pull last 100 tweets from each outlet.
* Perform a sentiment analysis with the compound, positive, neutral, and negative scoring for each tweet. 
* Pull into a DataFrame the tweet's source acount, its text, its date, and its compound, positive, neutral, and negative sentiment scores.
* Export the data in the DataFrame into a CSV file.
* Save PNG images for each plot.

As final considerations:

* Use the Matplotlib and Seaborn libraries.
* Include a written description of three observable trends based on the data. 
* Include proper labeling of your plots, including plot titles (with date of analysis) and axes labels.
* Include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.  




```python
# Dependencies
import tweepy
import json
import numpy as np
import requests as req
import pandas as pd
import matplotlib.pyplot as plt
import time
import seaborn as sns
from datetime import datetime
from scipy import stats

from matplotlib.font_manager import FontProperties

# Import and Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()

# Twitter API Keys
consumer_key = "HznpSY7QIAZ0EEtgCqUdd7BNG"
consumer_secret = "Avtpeem8WwjI00cqxRULxOMDNw5ObgsNxDJeta6KFaboSjJasl"
access_token = "971785066874580993-NfRif6uDrFp8AubFP5LPolFifn8ftIb"
access_token_secret = "cBWzmchL8BdYHJu9iizq7BGM13Ew7csRK1XdWyCMNKys3"

# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())


```


```python
# Target User Accounts
target_user = ("@BBCNews", "@CBSNews", "@CNN","@FoxNews","@nytimes")

# Array of Eligible Tweets
tweet_array = []

# Array to hold sentiment
sentiment_array = []

# Create variable for holding the oldest tweet
oldest_tweet = ""
count = 0

# Variables for holding sentiments
news_agency = []
tweet_text = []
tweet_times = []
compound_list = []
positive_list = []
negative_list = []
neutral_list = []
counter = []
color = []

# Loop through all target users
for target in target_user:

    # Loop through 5 times (total of 100 tweets)
    for x in range(1):
        #print(target)
        # Run search around each tweet
        public_tweets = api.search(target, count=100, result_type="recent",max_id=oldest_tweet)

        #print(public_tweets)

        # Loop through all tweets
        for tweet in public_tweets["statuses"]:

            # Run Vader Analysis on each tweet
            #Pull into a DataFrame the tweet's source acount, its text, its date, and its compound, positive, neutral, and negative sentiment scores.
            compound = analyzer.polarity_scores(tweet["text"])["compound"]
            pos = analyzer.polarity_scores(tweet["text"])["pos"]
            neu = analyzer.polarity_scores(tweet["text"])["neu"]
            neg = analyzer.polarity_scores(tweet["text"])["neg"]

            #print(compound)
            count += 1

            # Add each value to the appropriate array
            #print("before append")
            #print(target)
            news_agency.append(target)
            tweet_text.append(tweet["text"])
            tweet_times.append(tweet["created_at"])
            compound_list.append(compound)
            positive_list.append(pos)
            negative_list.append(neg)
            neutral_list.append(neu)
            counter.append(count)
            #print(counter)

            #Add color
            #print(target)
            if target == "@BBCNews":
                color.append("lightskyblue")
            elif target == "@CBSNews":
                color.append("green")
            elif target == "@CNN":
                color.append("red")
            elif target == "@FoxNews":
                color.append("blue")
            elif target == "@nytimes":
                color.append("yellow")
            #print(color)

# Store the Average Sentiments
#print(len(news_agency))
#print(len(tweet_text))
#print(len(tweet_times))
#print(len(compound_list))
#print(len(positive_list))
#print(len(negative_list))
#print(len(neutral_list))
#print(len(counter))
#print(len(color))

sentiment = {"NewsAgency": news_agency,
             "Tweet_Text": tweet_text,
             "Tweet_Date": tweet_times,
             "Compound": compound_list,
             "Positive": positive_list,
             "Neutral": negative_list,
             "Negative": neutral_list,
             "Tweet Count": len(compound_list),
             "count":counter,
             "color":color
            }

sentiment_df = pd.DataFrame(sentiment)
sentiment_df.to_csv("Sentiment_Analysis_Data")
```


```python
# Convert all tweet times into datetime objects
tweet_time_objects = []

# Add each datetime object into the array
for x in range(len(tweet_times)):
    tweet_datetime = datetime.strptime(tweet_times[x], "%a %b %d %H:%M:%S %z %Y")
    tweet_time_objects.append(tweet_datetime)
    #print(tweet_datetime)

    # Preview that datetimes are matching
    if x % 100 == 0:
        print(tweet_times[x])
        print(tweet_datetime)

# Calculate the time between tweets
time_in_between = []

# Calculate the time in between each tweet
for x in range(len(tweet_time_objects)-1):
    hrs_apart = ((tweet_time_objects[x] - tweet_time_objects[x+1]).seconds) / 3600  #calculates hours
    time_in_between.append(hrs_apart)

    
```

    Sat Mar 24 01:27:35 +0000 2018
    2018-03-24 01:27:35+00:00
    Sat Mar 24 01:27:28 +0000 2018
    2018-03-24 01:27:28+00:00
    Sat Mar 24 01:28:10 +0000 2018
    2018-03-24 01:28:10+00:00
    Sat Mar 24 01:28:10 +0000 2018
    2018-03-24 01:28:10+00:00
    Sat Mar 24 01:28:11 +0000 2018
    2018-03-24 01:28:11+00:00
    


```python
#Be a scatter plot of sentiments of the last 100 tweets sent out by each news organization, 
#ranging from -1.0 to 1.0, where a score of 0 expresses a neutral sentiment, 
#-1 the most negative sentiment possible, and +1 the most positive sentiment possible
#print(len(str(count)))

#print(sentiment_df["count"])
#print(sentiment_df["Compound"])

#print(time_in_between)
#print(sentiment_df.head())
#print(sentiment_df.loc[sentiment_df["NewsAgency"]=="@BBCNews"])

#target_user = ("@BBCNews", "@CBSNews", "@CNN","@FoxNews","@nytimes")
#for target in target_user:
    
sentiment_bbc_df = pd.DataFrame(sentiment_df.loc[sentiment_df["NewsAgency"]=="@BBCNews"])
sentiment_cbs_df = pd.DataFrame(sentiment_df.loc[sentiment_df["NewsAgency"]=="@CBSNews"])
sentiment_cnn_df = pd.DataFrame(sentiment_df.loc[sentiment_df["NewsAgency"]=="@CNN"])
sentiment_fox_df = pd.DataFrame(sentiment_df.loc[sentiment_df["NewsAgency"]=="@FoxNews"])
sentiment_nyt_df = pd.DataFrame(sentiment_df.loc[sentiment_df["NewsAgency"]=="@nytimes"])

#print(sentiment_cbs_df.head())

sentiment_cbs_df = sentiment_cbs_df.reset_index()
#sentiment_cbs_df.columns[0] = 'New_ID'
sentiment_cbs_df['New_ID'] = sentiment_cbs_df.index - 100

sentiment_cnn_df = sentiment_cnn_df.reset_index()
#sentiment_cnn_df.columns[0] = 'New_ID'
sentiment_cnn_df['New_ID'] = sentiment_cnn_df.index - 200

sentiment_fox_df = sentiment_fox_df.reset_index()
#sentiment_fox_df.columns[0] = 'New_ID'
sentiment_fox_df['New_ID'] = sentiment_fox_df.index - 300

sentiment_nyt_df = sentiment_nyt_df.reset_index()
#sentiment_nyt_df.columns[0] = 'New_ID'
sentiment_nyt_df['New_ID'] = sentiment_nyt_df.index - 400


#print(sentiment_bbc_df.head())
#print(sentiment_cbs_df.head())
#print(sentiment_cnn_df.head())
#print(sentiment_fox_df.head())
#print(sentiment_nyt_df.head())


```


```python
#print(sentiment_cbs_df.head())
#print(len(sentiment_bbc_df["Compound"]))
#print (len(time_in_between)+ 1)
print(range(len(sentiment_cbs_df['Tweet_Date'])))

###### BBC
# Convert all tweet times into datetime objects
tweet_time_objects_bbc = []

# Add each datetime object into the array
for x in range(len(sentiment_bbc_df['Tweet_Date'])):
    tweet_datetime = datetime.strptime(sentiment_bbc_df['Tweet_Date'][x], "%a %b %d %H:%M:%S %z %Y")
    tweet_time_objects_bbc.append(tweet_datetime)
    #print(tweet_datetime)

    # Preview that datetimes are matching
    if x % 100 == 0:
        print(sentiment_bbc_df['Tweet_Date'][x])
        #print(tweet_times[x])
        #print(tweet_datetime)

# Calculate the time between tweets
time_in_between_bbc = []

# Calculate the time in between each tweet
for x in range(len(tweet_time_objects_bbc)-1):
    hrs_apart = ((tweet_time_objects_bbc[x] - tweet_time_objects_bbc[x+1]).seconds) / 3600  #calculates hours
    time_in_between_bbc.append(hrs_apart)


```

    range(0, 100)
    Sat Mar 24 01:27:35 +0000 2018
    


```python

###### BBC
# Convert all tweet times into datetime objects
tweet_time_objects_bbc = []

# Add each datetime object into the array
print( sentiment_bbc_df['Tweet_Date'][x])
for x in range(len(sentiment_bbc_df['Tweet_Date'])):
    tweet_datetime = datetime.strptime(sentiment_bbc_df['Tweet_Date'][x], "%a %b %d %H:%M:%S %z %Y")
    #converted_time = datetime.strptime(raw_time, "%a %b %d %H:%M:%S %z %Y")

    tweet_time_objects_bbc.append(tweet_datetime)
    #print(tweet_datetime)

    # Preview that datetimes are matching
    if x % 100 == 0:
        print(sentiment_bbc_df['Tweet_Date'][x])
        #print(tweet_times[x])
        #print(tweet_datetime)

# Calculate the time between tweets
time_in_between_bbc = []

# Calculate the time in between each tweet
for x in range(len(tweet_time_objects_bbc)-1):
    hrs_apart = ((tweet_time_objects_bbc[x] - tweet_time_objects_bbc[x+1]).seconds) / 3600  #calculates hours
    time_in_between_bbc.append(hrs_apart)

#print(time_in_between_bbc)
```

    Sat Mar 24 01:08:59 +0000 2018
    Sat Mar 24 01:27:35 +0000 2018
    


```python
#print(len(sentiment_cbs_df['Tweet_Date']))
#print(sentiment_cbs_df["Tweet_Date"])


###### CBS
# Convert all tweet times into datetime objects
tweet_time_objects_cbs = []

# Add each datetime object into the array
#print( sentiment_cbs_df['Tweet_Date'][x])

for x in range(len(sentiment_cbs_df['Tweet_Date'])):
    tweet_datetime = datetime.strptime(sentiment_cbs_df['Tweet_Date'][x], "%a %b %d %H:%M:%S %z %Y")
    #print(tweet_datetime)
    tweet_time_objects_cbs.append(tweet_datetime)
    #print(tweet_time_objects_cbs)
    
    # Preview that datetimes are matching
    if x % 100 == 0:
        print(sentiment_cbs_df['Tweet_Date'][x])

    x += 1

# Calculate the time between tweets
time_in_between_cbs = []

# Calculate the time in between each tweet
print(range(len(tweet_time_objects_cbs)-1))

for x in range(len(tweet_time_objects_cbs)-1):
    #print("in for loop")
    hrs_apart = ((tweet_time_objects_cbs[x] - tweet_time_objects_cbs[x+1]).seconds) / 3600  #calculates hours
    time_in_between_cbs.append(hrs_apart)

#time_in_between_cbs
```

    Sat Mar 24 01:27:28 +0000 2018
    range(0, 99)
    


```python
######CNN
# Convert all tweet times into datetime objects
tweet_time_objects_cnn = []

# Add each datetime object into the array
#for x in range(len(sentiment_cnn_df['Tweet_Date'])):
#    tweet_datetime = datetime.strptime(sentiment_cnn_df['Tweet_Date'][x], "%a %b %d %H:%M:%S %z %Y")
#    tweet_time_objects_cnn.append(tweet_datetime)
    

# Add each datetime object into the array
for x in range(len(sentiment_cnn_df['Tweet_Date'])):
    tweet_datetime_cnn = datetime.strptime(sentiment_cnn_df['Tweet_Date'][x], "%a %b %d %H:%M:%S %z %Y")
    tweet_time_objects_cnn.append(tweet_datetime_cnn)
    #print(tweet_datetime)

    # Preview that datetimes are matching
    if x % 100 == 0:
        print(sentiment_cnn_df['Tweet_Date'][x])
        #print(tweet_times[x])
        #print(tweet_datetime)

# Calculate the time between tweets
time_in_between_cnn = []

# Calculate the time in between each tweet
for x in range(len(tweet_time_objects_cnn)-1):
    hrs_apart_cnn = ((tweet_time_objects_cnn[x] - tweet_time_objects_cnn[x+1]).seconds) / 3600  #calculates hours
    time_in_between_cnn.append(hrs_apart_cnn)

#######  


```

    Sat Mar 24 01:28:10 +0000 2018
    


```python
sentiment_fox_df = sentiment_fox_df.reset_index()
#sentiment_fox_df.columns[0] = 'New_ID'
sentiment_fox_df['New_ID'] = sentiment_fox_df.index - 300

print(sentiment_fox_df)
######FOX
# Convert all tweet times into datetime objects
tweet_time_objects_fox = []

# Add each datetime object into the array
for x in range(len(sentiment_fox_df['Tweet_Date'])):
    tweet_datetime = datetime.strptime(sentiment_fox_df['Tweet_Date'][x], "%a %b %d %H:%M:%S %z %Y")
    tweet_time_objects_fox.append(tweet_datetime)
    

    # Preview that datetimes are matching
    if x % 100 == 0:
        print(sentiment_fox_df['Tweet_Date'][x])
        #print(tweet_times[x])
        #print(tweet_datetime)

# Calculate the time between tweets
time_in_between_fox = []

# Calculate the time in between each tweet
for x in range(len(tweet_time_objects_fox)-1):
    hrs_apart = ((tweet_time_objects_fox[x] - tweet_time_objects_fox[x+1]).seconds) / 3600  #calculates hours
    time_in_between_fox.append(hrs_apart)

#######    

    

```

        level_0  index  Compound  Negative  Neutral NewsAgency  Positive  \
    0         0    300   -0.7184     0.708    0.292   @FoxNews     0.000   
    1         1    301    0.0000     1.000    0.000   @FoxNews     0.000   
    2         2    302   -0.8074     0.700    0.300   @FoxNews     0.000   
    3         3    303   -0.4648     0.862    0.138   @FoxNews     0.000   
    4         4    304    0.4767     0.367    0.174   @FoxNews     0.459   
    5         5    305   -0.8225     0.699    0.301   @FoxNews     0.000   
    6         6    306    0.0000     1.000    0.000   @FoxNews     0.000   
    7         7    307    0.3612     0.894    0.000   @FoxNews     0.106   
    8         8    308    0.4939     0.882    0.000   @FoxNews     0.118   
    9         9    309   -0.3400     0.882    0.118   @FoxNews     0.000   
    10       10    310    0.4215     0.872    0.000   @FoxNews     0.128   
    11       11    311   -0.6360     0.698    0.302   @FoxNews     0.000   
    12       12    312    0.0000     1.000    0.000   @FoxNews     0.000   
    13       13    313   -0.7184     0.708    0.292   @FoxNews     0.000   
    14       14    314    0.4740     0.829    0.000   @FoxNews     0.171   
    15       15    315    0.0000     1.000    0.000   @FoxNews     0.000   
    16       16    316   -0.5106     0.548    0.452   @FoxNews     0.000   
    17       17    317    0.3818     0.741    0.081   @FoxNews     0.178   
    18       18    318    0.0000     1.000    0.000   @FoxNews     0.000   
    19       19    319    0.0000     1.000    0.000   @FoxNews     0.000   
    20       20    320    0.3612     0.667    0.000   @FoxNews     0.333   
    21       21    321    0.5960     0.739    0.000   @FoxNews     0.261   
    22       22    322    0.0000     1.000    0.000   @FoxNews     0.000   
    23       23    323   -0.7184     0.708    0.292   @FoxNews     0.000   
    24       24    324    0.0000     1.000    0.000   @FoxNews     0.000   
    25       25    325    0.3612     0.884    0.000   @FoxNews     0.116   
    26       26    326   -0.7184     0.708    0.292   @FoxNews     0.000   
    27       27    327    0.3818     0.741    0.081   @FoxNews     0.178   
    28       28    328    0.0000     0.694    0.153   @FoxNews     0.153   
    29       29    329   -0.0258     0.823    0.091   @FoxNews     0.086   
    ..      ...    ...       ...       ...      ...        ...       ...   
    70       70    370   -0.7184     0.708    0.292   @FoxNews     0.000   
    71       71    371   -0.5994     0.656    0.247   @FoxNews     0.097   
    72       72    372    0.3818     0.880    0.000   @FoxNews     0.120   
    73       73    373   -0.7184     0.708    0.292   @FoxNews     0.000   
    74       74    374   -0.1531     0.663    0.187   @FoxNews     0.151   
    75       75    375    0.3400     0.533    0.184   @FoxNews     0.283   
    76       76    376   -0.3182     0.722    0.181   @FoxNews     0.097   
    77       77    377   -0.2500     0.484    0.298   @FoxNews     0.218   
    78       78    378    0.0000     1.000    0.000   @FoxNews     0.000   
    79       79    379   -0.7184     0.708    0.292   @FoxNews     0.000   
    80       80    380   -0.5267     0.866    0.134   @FoxNews     0.000   
    81       81    381   -0.7177     0.760    0.240   @FoxNews     0.000   
    82       82    382   -0.7184     0.708    0.292   @FoxNews     0.000   
    83       83    383   -0.4101     0.646    0.354   @FoxNews     0.000   
    84       84    384    0.0772     0.822    0.000   @FoxNews     0.178   
    85       85    385    0.0000     1.000    0.000   @FoxNews     0.000   
    86       86    386   -0.7184     0.708    0.292   @FoxNews     0.000   
    87       87    387   -0.6486     0.791    0.209   @FoxNews     0.000   
    88       88    388   -0.3400     0.882    0.118   @FoxNews     0.000   
    89       89    389    0.0000     1.000    0.000   @FoxNews     0.000   
    90       90    390    0.0000     1.000    0.000   @FoxNews     0.000   
    91       91    391    0.6249     0.823    0.000   @FoxNews     0.177   
    92       92    392    0.5574     0.841    0.000   @FoxNews     0.159   
    93       93    393   -0.7184     0.708    0.292   @FoxNews     0.000   
    94       94    394   -0.3818     0.667    0.221   @FoxNews     0.113   
    95       95    395   -0.4404     0.580    0.420   @FoxNews     0.000   
    96       96    396    0.7417     0.705    0.000   @FoxNews     0.295   
    97       97    397    0.0000     1.000    0.000   @FoxNews     0.000   
    98       98    398    0.1593     0.492    0.232   @FoxNews     0.276   
    99       99    399    0.0000     1.000    0.000   @FoxNews     0.000   
    
        Tweet Count                      Tweet_Date  \
    0           500  Sat Mar 24 01:28:10 +0000 2018   
    1           500  Sat Mar 24 01:28:10 +0000 2018   
    2           500  Sat Mar 24 01:28:09 +0000 2018   
    3           500  Sat Mar 24 01:28:09 +0000 2018   
    4           500  Sat Mar 24 01:28:09 +0000 2018   
    5           500  Sat Mar 24 01:28:09 +0000 2018   
    6           500  Sat Mar 24 01:28:09 +0000 2018   
    7           500  Sat Mar 24 01:28:08 +0000 2018   
    8           500  Sat Mar 24 01:28:08 +0000 2018   
    9           500  Sat Mar 24 01:28:08 +0000 2018   
    10          500  Sat Mar 24 01:28:07 +0000 2018   
    11          500  Sat Mar 24 01:28:07 +0000 2018   
    12          500  Sat Mar 24 01:28:07 +0000 2018   
    13          500  Sat Mar 24 01:28:05 +0000 2018   
    14          500  Sat Mar 24 01:28:05 +0000 2018   
    15          500  Sat Mar 24 01:28:04 +0000 2018   
    16          500  Sat Mar 24 01:28:04 +0000 2018   
    17          500  Sat Mar 24 01:28:04 +0000 2018   
    18          500  Sat Mar 24 01:28:04 +0000 2018   
    19          500  Sat Mar 24 01:28:03 +0000 2018   
    20          500  Sat Mar 24 01:28:03 +0000 2018   
    21          500  Sat Mar 24 01:28:03 +0000 2018   
    22          500  Sat Mar 24 01:28:02 +0000 2018   
    23          500  Sat Mar 24 01:28:02 +0000 2018   
    24          500  Sat Mar 24 01:28:02 +0000 2018   
    25          500  Sat Mar 24 01:28:01 +0000 2018   
    26          500  Sat Mar 24 01:28:01 +0000 2018   
    27          500  Sat Mar 24 01:28:01 +0000 2018   
    28          500  Sat Mar 24 01:28:01 +0000 2018   
    29          500  Sat Mar 24 01:28:01 +0000 2018   
    ..          ...                             ...   
    70          500  Sat Mar 24 01:27:44 +0000 2018   
    71          500  Sat Mar 24 01:27:43 +0000 2018   
    72          500  Sat Mar 24 01:27:43 +0000 2018   
    73          500  Sat Mar 24 01:27:42 +0000 2018   
    74          500  Sat Mar 24 01:27:42 +0000 2018   
    75          500  Sat Mar 24 01:27:40 +0000 2018   
    76          500  Sat Mar 24 01:27:39 +0000 2018   
    77          500  Sat Mar 24 01:27:38 +0000 2018   
    78          500  Sat Mar 24 01:27:38 +0000 2018   
    79          500  Sat Mar 24 01:27:37 +0000 2018   
    80          500  Sat Mar 24 01:27:36 +0000 2018   
    81          500  Sat Mar 24 01:27:36 +0000 2018   
    82          500  Sat Mar 24 01:27:36 +0000 2018   
    83          500  Sat Mar 24 01:27:35 +0000 2018   
    84          500  Sat Mar 24 01:27:35 +0000 2018   
    85          500  Sat Mar 24 01:27:35 +0000 2018   
    86          500  Sat Mar 24 01:27:35 +0000 2018   
    87          500  Sat Mar 24 01:27:35 +0000 2018   
    88          500  Sat Mar 24 01:27:34 +0000 2018   
    89          500  Sat Mar 24 01:27:33 +0000 2018   
    90          500  Sat Mar 24 01:27:33 +0000 2018   
    91          500  Sat Mar 24 01:27:33 +0000 2018   
    92          500  Sat Mar 24 01:27:32 +0000 2018   
    93          500  Sat Mar 24 01:27:31 +0000 2018   
    94          500  Sat Mar 24 01:27:31 +0000 2018   
    95          500  Sat Mar 24 01:27:31 +0000 2018   
    96          500  Sat Mar 24 01:27:31 +0000 2018   
    97          500  Sat Mar 24 01:27:30 +0000 2018   
    98          500  Sat Mar 24 01:27:30 +0000 2018   
    99          500  Sat Mar 24 01:27:30 +0000 2018   
    
                                               Tweet_Text color  count  New_ID  
    0   RT @TuckerCarlson: Forget Russia hysteria or C...  blue    301    -300  
    1   RT @HaleyCHalverson: My op-ed in @FoxNews ⬇️\n...  blue    302    -299  
    2   @lesterecaldwell @FoxNews @realDonaldTrump Wha...  blue    303    -298  
    3   RT @OMGno2trump: ATTENTION #MAGA:  US STOCK MA...  blue    304    -297  
    4   @TuckerCarlson @FoxNews Yes, forget Russia.  P...  blue    305    -296  
    5   @kcimary @Castzky99 @FoxNews You know what... ...  blue    306    -295  
    6   RT @dennis0805a: @krassenstein In addition, Tr...  blue    307    -294  
    7   RT @OMGno2trump: OMG, it looks like Trump is h...  blue    308    -293  
    8   @kathy_owrey @FoxNews The idea at the time was...  blue    309    -292  
    9   RT @FoxNews: In a new op-ed, former FBI Deputy...  blue    310    -291  
    10  @TuckerCarlson @FoxNews Most people think that...  blue    311    -290  
    11  @FoxNews @realDonaldTrump And even if you lied...  blue    312    -289  
    12  @TuckerCarlson @FoxNews I was trained by my fa...  blue    313    -288  
    13  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    314    -287  
    14  @AZpapergirl @realDonaldTrump @FoxNews I compl...  blue    315    -286  
    15  THIS is the REAL COLLUSION! #tcot #cnn #bcot @...  blue    316    -285  
    16            @TuckerCarlson @FoxNews You terrify me.  blue    317    -284  
    17  RT @FoxNews: .@TuckerCarlson: "We're told we n...  blue    318    -283  
    18  @FoxNews @realDonaldTrump  https://t.co/wp9Iph...  blue    319    -282  
    19  @FoxNews @realDonaldTrump https://t.co/0Zq6cTBf3Q  blue    320    -281  
    20  @chuckupd @dmaliciouz @RobertW05827506 @FoxNew...  blue    321    -280  
    21  @TuckerCarlson @brianstelter Um, @FoxNews func...  blue    322    -279  
    22  @FoxNews @realDonaldTrump You ought to write a...  blue    323    -278  
    23  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    324    -277  
    24  RT @dennis0805a: @krassenstein In addition, Tr...  blue    325    -276  
    25  RT @OMGno2trump: OMG, Trump has hired 6 @FoxNe...  blue    326    -275  
    26  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    327    -274  
    27  RT @FoxNews: .@TuckerCarlson: "We're told we n...  blue    328    -273  
    28  @FoxNews @TuckerCarlson #suckercarlson has bee...  blue    329    -272  
    29  @FoxNews @POTUS After the stunt you pulled tod...  blue    330    -271  
    ..                                                ...   ...    ...     ...  
    70  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    371    -230  
    71  @FoxNews @realDonaldTrump Baby, suck it up you...  blue    372    -229  
    72  @FoxNews I think we need to protect ourselves ...  blue    373    -228  
    73  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    374    -227  
    74  @FoxNews @RealMGrimm @seanhannity Poor Sean Ha...  blue    375    -226  
    75  @no1important701 @LIVE_COVERAGE @Canes228 @Fox...  blue    376    -225  
    76  RT @6bird4: It is ridiculous that Jeff Zucker ...  blue    377    -224  
    77    @FoxNews Republicans are now the party of chaos  blue    378    -223  
    78  RT @FoxNews: .@POTUS holds a news conference o...  blue    379    -222  
    79  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    380    -221  
    80  RT @FoxNews: Charles Hurt on spending bill: "C...  blue    381    -220  
    81  @FoxNews @BrianCHouston Then we are not a Chri...  blue    382    -219  
    82  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    383    -218  
    83  @FoxNews @brannon_debbie @JessicaTarlov Jessic...  blue    384    -217  
    84    @FoxNews @ChrisStirewalt That is what they want  blue    385    -216  
    85  @DrYardSale @DeanDesign101 @MonaMdmeupanova @1...  blue    386    -215  
    86  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    387    -214  
    87  @FoxNews @POTUS its a shame you can't have it ...  blue    388    -213  
    88  RT @FoxNews: In a new op-ed, former FBI Deputy...  blue    389    -212  
    89  @sPeciAULized @RUGER11817330 @bessy_c3 @FoxNew...  blue    390    -211  
    90  @FoxNews @realDonaldTrump https://t.co/UWIapfVWrq  blue    391    -210  
    91  RT @FoxNews: Great Pacific Garbage Patch, floa...  blue    392    -209  
    92  RT @BlueRidgeLEO: Domestic Goddess, &amp; toda...  blue    393    -208  
    93  RT @TuckerCarlson: Forget Russia hysteria or C...  blue    394    -207  
    94  @susan_urbatsch @Undra2000 @FoxNews Never said...  blue    395    -206  
    95  @FoxNews @realDonaldTrump Dirty just dirty.......  blue    396    -205  
    96  RT @GregGutfeldShow: TGIF!! Don't forget to wa...  blue    397    -204  
    97  RT @snarky_op: .@realDonaldTrump @GOP @OrrinHa...  blue    398    -203  
    98  RT @viralexposureco: ♥️ RETWEET SHARE SUPPORT!...  blue    399    -202  
    99  @dmaliciouz @CarlaBattles1 @LoriB157 @FoxNews ...  blue    400    -201  
    
    [100 rows x 13 columns]
    Sat Mar 24 01:28:10 +0000 2018
    


```python
sentiment_nyt_df = sentiment_nyt_df.reset_index()
#sentiment_nyt_df.columns[0] = 'New_ID'
sentiment_nyt_df['New_ID'] = sentiment_nyt_df.index - 400

print(sentiment_nyt_df)

###### NYT
# Convert all tweet times into datetime objects
tweet_time_objects_nyt = []

# Add each datetime object into the array
for z in range(len(sentiment_nyt_df['Tweet_Date'])):
    tweet_datetime = datetime.strptime(sentiment_nyt_df['Tweet_Date'][z], "%a %b %d %H:%M:%S %z %Y")
    tweet_time_objects_nyt.append(tweet_datetime)
    

    # Preview that datetimes are matching
    if x % 100 == 0:
        print(sentiment_nyt_df['Tweet_Date'][x])
        #print(tweet_times[x])
        #print(tweet_datetime)

# Calculate the time between tweets
time_in_between_nyt = []

# Calculate the time in between each tweet
for x in range(len(tweet_time_objects_nyt)-1):
    hrs_apart = ((tweet_time_objects_nyt[x] - tweet_time_objects_nyt[x+1]).seconds) / 3600  #calculates hours
    time_in_between_nyt.append(hrs_apart)

#######    


```

        level_0  index  Compound  Negative  Neutral NewsAgency  Positive  \
    0         0    400    0.4404     0.838    0.000   @nytimes     0.162   
    1         1    401    0.0000     1.000    0.000   @nytimes     0.000   
    2         2    402    0.0000     1.000    0.000   @nytimes     0.000   
    3         3    403    0.0000     1.000    0.000   @nytimes     0.000   
    4         4    404    0.0000     1.000    0.000   @nytimes     0.000   
    5         5    405    0.4019     0.881    0.000   @nytimes     0.119   
    6         6    406    0.0000     1.000    0.000   @nytimes     0.000   
    7         7    407   -0.5106     0.830    0.170   @nytimes     0.000   
    8         8    408   -0.0772     0.812    0.081   @nytimes     0.107   
    9         9    409    0.0000     1.000    0.000   @nytimes     0.000   
    10       10    410    0.3182     0.836    0.058   @nytimes     0.105   
    11       11    411    0.6705     0.686    0.000   @nytimes     0.314   
    12       12    412    0.0000     1.000    0.000   @nytimes     0.000   
    13       13    413    0.0000     1.000    0.000   @nytimes     0.000   
    14       14    414   -0.9029     0.618    0.382   @nytimes     0.000   
    15       15    415    0.0000     1.000    0.000   @nytimes     0.000   
    16       16    416    0.4588     0.810    0.000   @nytimes     0.190   
    17       17    417   -0.3400     0.769    0.231   @nytimes     0.000   
    18       18    418    0.0000     1.000    0.000   @nytimes     0.000   
    19       19    419    0.0000     1.000    0.000   @nytimes     0.000   
    20       20    420   -0.4404     0.873    0.127   @nytimes     0.000   
    21       21    421    0.0000     1.000    0.000   @nytimes     0.000   
    22       22    422    0.0000     1.000    0.000   @nytimes     0.000   
    23       23    423    0.0000     1.000    0.000   @nytimes     0.000   
    24       24    424    0.0000     0.522    0.239   @nytimes     0.239   
    25       25    425    0.4767     0.807    0.000   @nytimes     0.193   
    26       26    426   -0.1027     0.931    0.069   @nytimes     0.000   
    27       27    427   -0.0772     0.812    0.081   @nytimes     0.107   
    28       28    428    0.0000     1.000    0.000   @nytimes     0.000   
    29       29    429   -0.5106     0.830    0.170   @nytimes     0.000   
    ..      ...    ...       ...       ...      ...        ...       ...   
    70       70    470   -0.0772     0.812    0.081   @nytimes     0.107   
    71       71    471   -0.6705     0.852    0.148   @nytimes     0.000   
    72       72    472   -0.5106     0.738    0.173   @nytimes     0.089   
    73       73    473    0.0000     1.000    0.000   @nytimes     0.000   
    74       74    474   -0.5256     0.816    0.184   @nytimes     0.000   
    75       75    475   -0.0772     0.812    0.081   @nytimes     0.107   
    76       76    476   -0.0772     0.812    0.081   @nytimes     0.107   
    77       77    477   -0.4019     0.876    0.124   @nytimes     0.000   
    78       78    478    0.0000     1.000    0.000   @nytimes     0.000   
    79       79    479    0.4019     0.687    0.120   @nytimes     0.193   
    80       80    480    0.0000     1.000    0.000   @nytimes     0.000   
    81       81    481   -0.7579     0.562    0.329   @nytimes     0.108   
    82       82    482   -0.0772     0.812    0.081   @nytimes     0.107   
    83       83    483    0.5994     0.542    0.129   @nytimes     0.329   
    84       84    484   -0.5106     0.738    0.173   @nytimes     0.089   
    85       85    485    0.0000     1.000    0.000   @nytimes     0.000   
    86       86    486   -0.5106     0.377    0.623   @nytimes     0.000   
    87       87    487    0.0000     1.000    0.000   @nytimes     0.000   
    88       88    488   -0.5106     0.738    0.173   @nytimes     0.089   
    89       89    489    0.9252     0.573    0.000   @nytimes     0.427   
    90       90    490    0.0000     1.000    0.000   @nytimes     0.000   
    91       91    491   -0.7579     0.562    0.329   @nytimes     0.108   
    92       92    492    0.0000     1.000    0.000   @nytimes     0.000   
    93       93    493   -0.0772     0.812    0.081   @nytimes     0.107   
    94       94    494    0.0000     1.000    0.000   @nytimes     0.000   
    95       95    495    0.0000     1.000    0.000   @nytimes     0.000   
    96       96    496   -0.5106     0.830    0.170   @nytimes     0.000   
    97       97    497    0.0000     1.000    0.000   @nytimes     0.000   
    98       98    498    0.0000     1.000    0.000   @nytimes     0.000   
    99       99    499   -0.0772     0.812    0.081   @nytimes     0.107   
    
        Tweet Count                      Tweet_Date  \
    0           500  Sat Mar 24 01:28:11 +0000 2018   
    1           500  Sat Mar 24 01:28:07 +0000 2018   
    2           500  Sat Mar 24 01:28:06 +0000 2018   
    3           500  Sat Mar 24 01:28:00 +0000 2018   
    4           500  Sat Mar 24 01:27:59 +0000 2018   
    5           500  Sat Mar 24 01:27:59 +0000 2018   
    6           500  Sat Mar 24 01:27:58 +0000 2018   
    7           500  Sat Mar 24 01:27:57 +0000 2018   
    8           500  Sat Mar 24 01:27:53 +0000 2018   
    9           500  Sat Mar 24 01:27:49 +0000 2018   
    10          500  Sat Mar 24 01:27:48 +0000 2018   
    11          500  Sat Mar 24 01:27:47 +0000 2018   
    12          500  Sat Mar 24 01:27:46 +0000 2018   
    13          500  Sat Mar 24 01:27:46 +0000 2018   
    14          500  Sat Mar 24 01:27:45 +0000 2018   
    15          500  Sat Mar 24 01:27:45 +0000 2018   
    16          500  Sat Mar 24 01:27:44 +0000 2018   
    17          500  Sat Mar 24 01:27:42 +0000 2018   
    18          500  Sat Mar 24 01:27:41 +0000 2018   
    19          500  Sat Mar 24 01:27:40 +0000 2018   
    20          500  Sat Mar 24 01:27:40 +0000 2018   
    21          500  Sat Mar 24 01:27:40 +0000 2018   
    22          500  Sat Mar 24 01:27:37 +0000 2018   
    23          500  Sat Mar 24 01:27:37 +0000 2018   
    24          500  Sat Mar 24 01:27:33 +0000 2018   
    25          500  Sat Mar 24 01:27:32 +0000 2018   
    26          500  Sat Mar 24 01:27:30 +0000 2018   
    27          500  Sat Mar 24 01:27:24 +0000 2018   
    28          500  Sat Mar 24 01:27:21 +0000 2018   
    29          500  Sat Mar 24 01:27:20 +0000 2018   
    ..          ...                             ...   
    70          500  Sat Mar 24 01:25:44 +0000 2018   
    71          500  Sat Mar 24 01:25:44 +0000 2018   
    72          500  Sat Mar 24 01:25:41 +0000 2018   
    73          500  Sat Mar 24 01:25:39 +0000 2018   
    74          500  Sat Mar 24 01:25:36 +0000 2018   
    75          500  Sat Mar 24 01:25:36 +0000 2018   
    76          500  Sat Mar 24 01:25:35 +0000 2018   
    77          500  Sat Mar 24 01:25:31 +0000 2018   
    78          500  Sat Mar 24 01:25:29 +0000 2018   
    79          500  Sat Mar 24 01:25:28 +0000 2018   
    80          500  Sat Mar 24 01:25:26 +0000 2018   
    81          500  Sat Mar 24 01:25:26 +0000 2018   
    82          500  Sat Mar 24 01:25:25 +0000 2018   
    83          500  Sat Mar 24 01:25:24 +0000 2018   
    84          500  Sat Mar 24 01:25:22 +0000 2018   
    85          500  Sat Mar 24 01:25:18 +0000 2018   
    86          500  Sat Mar 24 01:25:17 +0000 2018   
    87          500  Sat Mar 24 01:25:16 +0000 2018   
    88          500  Sat Mar 24 01:25:16 +0000 2018   
    89          500  Sat Mar 24 01:25:12 +0000 2018   
    90          500  Sat Mar 24 01:25:10 +0000 2018   
    91          500  Sat Mar 24 01:25:08 +0000 2018   
    92          500  Sat Mar 24 01:24:59 +0000 2018   
    93          500  Sat Mar 24 01:24:58 +0000 2018   
    94          500  Sat Mar 24 01:24:55 +0000 2018   
    95          500  Sat Mar 24 01:24:54 +0000 2018   
    96          500  Sat Mar 24 01:24:52 +0000 2018   
    97          500  Sat Mar 24 01:24:52 +0000 2018   
    98          500  Sat Mar 24 01:24:49 +0000 2018   
    99          500  Sat Mar 24 01:24:37 +0000 2018   
    
                                               Tweet_Text   color  count  New_ID  
    0   @nytimes we hope some of the senators will sta...  yellow    401    -400  
    1   RT @nytimes: John Bolton's political committee...  yellow    402    -399  
    2   RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    403    -398  
    3   RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    404    -397  
    4   RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    405    -396  
    5   @SenRichardBlack @Mexlumy @nytimes y should us...  yellow    406    -395  
    6   RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    407    -394  
    7   RT @nytimes: Over 800 protests for stricter gu...  yellow    408    -393  
    8   RT @nytimes: If we want to stop global warming...  yellow    409    -392  
    9   RT @CevansOfficial: More Photos from @nytimes ...  yellow    410    -391  
    10  RT @nytimes: We spoke to survivors of mass sho...  yellow    411    -390  
    11  RT @vimalscotkapoor: @docdanielle @nytimes Tru...  yellow    412    -389  
    12  RT @HannaIngber: We've heard from readers conc...  yellow    413    -388  
    13  RT @lauriegnyt: ‘Something About Parkland Has ...  yellow    414    -387  
    14  RT @JusticeInformer: Tony Robinson was a 19 ye...  yellow    415    -386  
    15  RT @lauriegnyt: ‘Something About Parkland Has ...  yellow    416    -385  
    16  @neiby @nytimes If one wishes to sell anything...  yellow    417    -384  
    17  @AlexandrainNYC @nytimes The farming industry ...  yellow    418    -383  
    18  RT @LouiseMensch: What the House Intel Committ...  yellow    419    -382  
    19  @Willis_Hubbard_ @adair1946 @Irysdawn @elainey...  yellow    420    -381  
    20  @nytimes This report is worthless there was en...  yellow    421    -380  
    21  @nytimes @brucerisk More power to their collec...  yellow    422    -379  
    22  @nytimes more people are leaving face book but...  yellow    423    -378  
    23  @CNN @MSNBC @CBS @nytimes @Oregonian @washingt...  yellow    424    -377  
    24  Quitting Heroin in the Sunshine State   via @N...  yellow    425    -376  
    25  RT @okilloran: Bolton Was Early Beneficiary of...  yellow    426    -375  
    26  @nytimes @readercenter With any story, how har...  yellow    427    -374  
    27  RT @nytimes: If we want to stop global warming...  yellow    428    -373  
    28  @KatyTurNBC @MSNBC @CNN @AriMelber @JoyAnnReid...  yellow    429    -372  
    29  RT @nytimes: Over 800 protests for stricter gu...  yellow    430    -371  
    ..                                                ...     ...    ...     ...  
    70  RT @nytimes: If we want to stop global warming...  yellow    471    -330  
    71  RT @nytimes: “He is still down, he is not movi...  yellow    472    -329  
    72  RT @StenderWorld: Exhibit A: a serial bombing ...  yellow    473    -328  
    73  @Lololupus @adair1946 @CHHolte @PDelarios @cle...  yellow    474    -327  
    74  RT @consmover: #WakeUpAmerica\n\nRight wing ex...  yellow    475    -326  
    75  RT @nytimes: If we want to stop global warming...  yellow    476    -325  
    76  RT @nytimes: If we want to stop global warming...  yellow    477    -324  
    77  This is one of the clearer examples of the egr...  yellow    478    -323  
    78  @KatyTurNBC @MSNBC @CNN @AriMelber @JoyAnnReid...  yellow    479    -322  
    79  RT @TheBeatWithAri: "We're seeing... this amaz...  yellow    480    -321  
    80  @LiuGang8964 @chgqzh @MaskedKnighter @changzha...  yellow    481    -320  
    81  RT @MuslimIQ: Yes @nytimes—you cover Christian...  yellow    482    -319  
    82  RT @nytimes: If we want to stop global warming...  yellow    483    -318  
    83  RT @hondanhon: This feels like a bullshit, vac...  yellow    484    -317  
    84  RT @StenderWorld: Exhibit A: a serial bombing ...  yellow    485    -316  
    85  RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    486    -315  
    86                       @danjonesccg @nytimes U dumb  yellow    487    -314  
    87  RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    488    -313  
    88  RT @StenderWorld: Exhibit A: a serial bombing ...  yellow    489    -312  
    89  I am so so proud of my talented colleagues. 🎉💕...  yellow    490    -311  
    90  RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    491    -310  
    91  RT @MuslimIQ: Yes @nytimes—you cover Christian...  yellow    492    -309  
    92  @Sam0Sigman @nytimes This is something people ...  yellow    493    -308  
    93  RT @nytimes: If we want to stop global warming...  yellow    494    -307  
    94  .@CNN @MSNBC @mmfa @moveon @dailykos @motherjo...  yellow    495    -306  
    95  @TimInHonolulu @nytimes Then you read many of ...  yellow    496    -305  
    96  RT @nytimes: Over 800 protests for stricter gu...  yellow    497    -304  
    97  @CdR_PA_TGN @CDRGarriga @tjparfitt @nytimes @t...  yellow    498    -303  
    98  RT @nytimes: In 1843, a 27-year-old Ada Lovela...  yellow    499    -302  
    99  RT @nytimes: If we want to stop global warming...  yellow    500    -301  
    
    [100 rows x 13 columns]
    


```python
#print(len(time_in_between_bbc))
#print(len(time_in_between_cbs))
#print(len(time_in_between_cnn))
#print(len(time_in_between_fox))
#print(len(time_in_between_nyt))

```

    99
    99
    99
    99
    99
    


```python
#print(sentiment_bbc_df["color"])
#print(sentiment_cbs_df["color"])
#print(sentiment_cnn_df["color"])
#print(sentiment_fox_df["color"])
#print(sentiment_nyt_df["color"])
```

    0     lightskyblue
    1     lightskyblue
    2     lightskyblue
    3     lightskyblue
    4     lightskyblue
    5     lightskyblue
    6     lightskyblue
    7     lightskyblue
    8     lightskyblue
    9     lightskyblue
    10    lightskyblue
    11    lightskyblue
    12    lightskyblue
    13    lightskyblue
    14    lightskyblue
    15    lightskyblue
    16    lightskyblue
    17    lightskyblue
    18    lightskyblue
    19    lightskyblue
    20    lightskyblue
    21    lightskyblue
    22    lightskyblue
    23    lightskyblue
    24    lightskyblue
    25    lightskyblue
    26    lightskyblue
    27    lightskyblue
    28    lightskyblue
    29    lightskyblue
              ...     
    70    lightskyblue
    71    lightskyblue
    72    lightskyblue
    73    lightskyblue
    74    lightskyblue
    75    lightskyblue
    76    lightskyblue
    77    lightskyblue
    78    lightskyblue
    79    lightskyblue
    80    lightskyblue
    81    lightskyblue
    82    lightskyblue
    83    lightskyblue
    84    lightskyblue
    85    lightskyblue
    86    lightskyblue
    87    lightskyblue
    88    lightskyblue
    89    lightskyblue
    90    lightskyblue
    91    lightskyblue
    92    lightskyblue
    93    lightskyblue
    94    lightskyblue
    95    lightskyblue
    96    lightskyblue
    97    lightskyblue
    98    lightskyblue
    99    lightskyblue
    Name: color, Length: 100, dtype: object
    0     green
    1     green
    2     green
    3     green
    4     green
    5     green
    6     green
    7     green
    8     green
    9     green
    10    green
    11    green
    12    green
    13    green
    14    green
    15    green
    16    green
    17    green
    18    green
    19    green
    20    green
    21    green
    22    green
    23    green
    24    green
    25    green
    26    green
    27    green
    28    green
    29    green
          ...  
    70    green
    71    green
    72    green
    73    green
    74    green
    75    green
    76    green
    77    green
    78    green
    79    green
    80    green
    81    green
    82    green
    83    green
    84    green
    85    green
    86    green
    87    green
    88    green
    89    green
    90    green
    91    green
    92    green
    93    green
    94    green
    95    green
    96    green
    97    green
    98    green
    99    green
    Name: color, Length: 100, dtype: object
    0     red
    1     red
    2     red
    3     red
    4     red
    5     red
    6     red
    7     red
    8     red
    9     red
    10    red
    11    red
    12    red
    13    red
    14    red
    15    red
    16    red
    17    red
    18    red
    19    red
    20    red
    21    red
    22    red
    23    red
    24    red
    25    red
    26    red
    27    red
    28    red
    29    red
         ... 
    70    red
    71    red
    72    red
    73    red
    74    red
    75    red
    76    red
    77    red
    78    red
    79    red
    80    red
    81    red
    82    red
    83    red
    84    red
    85    red
    86    red
    87    red
    88    red
    89    red
    90    red
    91    red
    92    red
    93    red
    94    red
    95    red
    96    red
    97    red
    98    red
    99    red
    Name: color, Length: 100, dtype: object
    300    blue
    301    blue
    302    blue
    303    blue
    304    blue
    305    blue
    306    blue
    307    blue
    308    blue
    309    blue
    310    blue
    311    blue
    312    blue
    313    blue
    314    blue
    315    blue
    316    blue
    317    blue
    318    blue
    319    blue
    320    blue
    321    blue
    322    blue
    323    blue
    324    blue
    325    blue
    326    blue
    327    blue
    328    blue
    329    blue
           ... 
    370    blue
    371    blue
    372    blue
    373    blue
    374    blue
    375    blue
    376    blue
    377    blue
    378    blue
    379    blue
    380    blue
    381    blue
    382    blue
    383    blue
    384    blue
    385    blue
    386    blue
    387    blue
    388    blue
    389    blue
    390    blue
    391    blue
    392    blue
    393    blue
    394    blue
    395    blue
    396    blue
    397    blue
    398    blue
    399    blue
    Name: color, Length: 100, dtype: object
    0     yellow
    1     yellow
    2     yellow
    3     yellow
    4     yellow
    5     yellow
    6     yellow
    7     yellow
    8     yellow
    9     yellow
    10    yellow
    11    yellow
    12    yellow
    13    yellow
    14    yellow
    15    yellow
    16    yellow
    17    yellow
    18    yellow
    19    yellow
    20    yellow
    21    yellow
    22    yellow
    23    yellow
    24    yellow
    25    yellow
    26    yellow
    27    yellow
    28    yellow
    29    yellow
           ...  
    70    yellow
    71    yellow
    72    yellow
    73    yellow
    74    yellow
    75    yellow
    76    yellow
    77    yellow
    78    yellow
    79    yellow
    80    yellow
    81    yellow
    82    yellow
    83    yellow
    84    yellow
    85    yellow
    86    yellow
    87    yellow
    88    yellow
    89    yellow
    90    yellow
    91    yellow
    92    yellow
    93    yellow
    94    yellow
    95    yellow
    96    yellow
    97    yellow
    98    yellow
    99    yellow
    Name: color, Length: 100, dtype: object
    


```python
plt.scatter(range(len(time_in_between_bbc)+1),sentiment_bbc_df["Compound"],c=sentiment_bbc_df["color"],label='BBC')
plt.scatter(range(len(time_in_between_cbs)+1),sentiment_cbs_df["Compound"],c=sentiment_cbs_df["color"],label = "CBS")
plt.scatter(range(len(time_in_between_cnn)+1),sentiment_cnn_df["Compound"],c=sentiment_cnn_df["color"],label = "CNN")
plt.scatter(range(len(time_in_between_fox)+1),sentiment_fox_df["Compound"],c=sentiment_fox_df["color"], label= 'Fox')
plt.scatter(range(len(time_in_between_nyt)+1),sentiment_nyt_df["Compound"],c=sentiment_nyt_df["color"], label = 'NYT')

plt.title("Sentiment Analysis of Media Tweets (03/20/2018)")
plt.xlabel("Tweets Ago")
plt.ylabel("Tweet Polarity")
plt.legend()


#x = np.arange(10)

#fig = plt.figure()
ax = plt.subplot(111)

#for i in xrange(5):
#    ax.plot(x, i * x, label='$y = %ix$'%i)

# Shrink current axis by 20%
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])

# Put a legend to the right of the current axis
ax.legend(title = "Media Sources", loc='center left', bbox_to_anchor=(1, 0.5))


plt.show()
plt.savefig("NewsMoodScatter.jpg")
```

    C:\Users\elise\Anaconda3\lib\site-packages\matplotlib\cbook\deprecation.py:106: MatplotlibDeprecationWarning: Adding an axes using the same arguments as a previous axes currently reuses the earlier instance.  In a future version, a new instance will always be created and returned.  Meanwhile, this warning can be suppressed, and the future behavior ensured, by passing a unique label to each axes instance.
      warnings.warn(message, mplDeprecation, stacklevel=1)
    


![png](output_13_1.png)



    <matplotlib.figure.Figure at 0x1db9dc06198>



```python
print(np.mean(sentiment_bbc_df["Compound"]))
print(np.mean(sentiment_cbs_df["Compound"]))
print(np.mean(sentiment_cnn_df["Compound"]))
print(np.mean(sentiment_fox_df["Compound"]))
print(np.mean(sentiment_nyt_df["Compound"]))

mean_list = []

mean_list.append(np.mean(sentiment_bbc_df["Compound"]))
mean_list.append(np.mean(sentiment_cbs_df["Compound"]))
mean_list.append(np.mean(sentiment_cnn_df["Compound"]))
mean_list.append(np.mean(sentiment_fox_df["Compound"]))
mean_list.append(np.mean(sentiment_nyt_df["Compound"]))

print(mean_list)

rects1 = plt.bar(sentiment_bbc_df["NewsAgency"], np.mean(sentiment_bbc_df["Compound"]))
plt.bar(sentiment_cbs_df["NewsAgency"], np.mean(sentiment_cbs_df["Compound"]))
plt.bar(sentiment_cnn_df["NewsAgency"], np.mean(sentiment_cnn_df["Compound"]))
plt.bar(sentiment_fox_df["NewsAgency"], np.mean(sentiment_fox_df["Compound"]))
plt.bar(sentiment_nyt_df["NewsAgency"], np.mean(sentiment_nyt_df["Compound"]))

plt.title("Overall Media Sentiment based on Twitter (3/21/2018)")
plt.xlabel("Twitter Polarity")

N=5
ind = np.arange(N)  # the x locations for the groups
width = 0.35       # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(ind, mean_list)

def autolabel(rects):
    """
    Attach a text label above each bar displaying its height
    """
    for rect in rects:
        height = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()/2., 1.05*height,
                '%d' % int(height),
                ha='center', va='bottom')

autolabel(rects1)

plt.show()

plt.savefig("NewsMood_Bar")

```

    -0.09802999999999995
    -0.102604
    -0.02952600000000002
    -0.15074300000000007
    -0.126502
    [-0.09802999999999995, -0.102604, -0.02952600000000002, -0.15074300000000007, -0.126502]
    


![png](output_14_1.png)



![png](output_14_2.png)



    <matplotlib.figure.Figure at 0x1dba02ffe10>



```python
# Plot Time Between Tweets
#plt.plot(range(len(time_in_between)), time_in_between, marker="o", 
#               linewidth=0.25, alpha=0.2, color="r")
#plt.xlim([0, len(time_in_between)])
#plt.ylabel("Hours Apart")
#plt.xlabel("Tweets Ago")
#plt.title("Tweet Velocity: %s" % target_user)
#plt.show()
```


![png](output_15_0.png)

